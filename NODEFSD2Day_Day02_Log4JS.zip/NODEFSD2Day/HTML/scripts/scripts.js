const userForm = document.getElementById("signup");
function getData(){
  fetch("http://localhost:8000/getemployees")
    .then(function(response){
      return(response.json())
    .then(function(data){
      displayData(data);
    });
  })
};
//
function displayData(arr) {
  const docDiv = document.getElementById('documents');
  const docList = document.createDocumentFragment();
  //
  arr.map(function(employee) {
    let divP = document.createElement('div');
    let empName = document.createElement('h3');
    let empPass = document.createElement('p');
    //
    empName.innerHTML = `${employee.empName}`;
    empPass.innerHTML = `${employee.empPass}`;
    //
    divP.appendChild(empName);
    divP.appendChild(empPass);
    docList.appendChild(divP);
  });
  docDiv.appendChild(docList);
}
//
