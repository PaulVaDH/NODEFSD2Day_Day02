function validateForm() {
  let alphaOnly = /^[A-Za-z]+$/;
  document.getElementById("nameMessage").innerHTML = "";
  document.getElementById("weightMessage").innerHTML = "";
  //
  return true;
}
