const controller = require('../controllers/controller');
let authUser = require('../controllers/auth');
module.exports = function(router){
  //
  router.get('/', controller.getdefault);
  //
  router.post('/addemployee', controller.addemployee);
  //
  router.get('/aboutus', authUser, controller.aboutus);
  //
  router.get('/getemployees', controller.getemployees);
  //
  router.get('/getemployee/:employeeName', controller.getemployee);
  //
  router.delete('/deletebyname', controller.deletebyname);
  //
  router.put('/updateemployee', controller.updateemployee);
  //
  router.post('/loginuser', controller.loginuser);
//
};
  