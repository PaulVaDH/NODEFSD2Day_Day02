//
function getData(){
  fetch("http://localhost:8000/getemployees")
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(err => console.log(err))
}


