function getData(){
  fetch("http://localhost:8000/getemployees")
    .then(function(response){
      return(response.json())
    .then(function(data){
      console.log(data);
    });
  })
};
//
function validateForm() {
  let alphaOnly = /^[A-Za-z]+$/;
  document.getElementById("nameMessage").innerHTML = "";
  document.getElementById("weightMessage").innerHTML = "";
  //
  return true;
}
