const userForm = document.getElementById("signup");
function getData(){
  fetch("http://localhost:8000/getemployees")
    .then(function(response){
      return(response.json())
    .then(function(data){
      displayData(data);
    });
  })
};
//
function displayData(arr) { 
	let outHTML = "";
	for(let i=0; i < arr.length; i++){
		outHTML+="<p>"+arr[i].empName + " using password " + arr[i].empPass + "</p>";
	}
	document.getElementById("documents").innerHTML = outHTML; 
}
//
userForm.addEventListener("submit", (e) => {
	e.preventDefault();
  let form = e.currentTarget;
	let formFields = new FormData(form);
  let formDataObject = Object.fromEntries(formFields.entries());
  console.log(formDataObject);
  fetch('http://localhost:8000/addemployee', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json',
		},
    body: JSON.stringify(formDataObject),
	})
  .then(function(response){
		console.log(response);
	}).catch(function(err){
		console.log(err);
	});
});	
//
function validateForm() {
  let alphaOnly = /^[A-Za-z]+$/;
  document.getElementById("nameMessage").innerHTML = "";
  document.getElementById("weightMessage").innerHTML = "";
  //
  return true;
}
